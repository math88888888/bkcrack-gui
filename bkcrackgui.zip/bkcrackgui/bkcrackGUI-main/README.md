# bkcrackGUI
## 运行
安装依赖
```shell
pip install -r requirements.txt
```
启动程序
```shell
python main.py
run.bat   都可以
```
如果缺少别的库自己安装即可


